Thanks to all bug reporters, and special thanks to those who have contributed
code:

    Brian Egan (brianegan):
          Initial compiling support

    Ches Martin (ches):
          Initial vim docs

    Chris Hoffman (cehoffman):
          Add new keywoards from, to, and do
          Highlight the - in negative integers
          Add here regex highlighting, increase fold level for here docs

    David Wilhelm (bigfish):
          CoffeeRun command

    Jay Adkisson (jayferd):
          Support for eco templates

    Karl Guertin (grayrest)
          Cakefiles are coffeescript

    Maciej Konieczny (narfdotpl):
          Fix funny typo

    Matt Sacks (mattsa):
          Javascript omni-completion
          coffee_compile_vert option

    Nick Stenning (nickstenning):
          Fold by indentation for coffeescript

    Simon Lipp (sloonz):
          Trailing spaces are not error on lines containing only spaces

    Stéphan Kochen (stephank):
          Initial HTML CoffeeScript highlighting

    Sven Felix Oberquelle (Svelix):
          Haml CoffeeScript highlighting

    Wei Dai (clvv):
          Fix the use of Vim built-in make command.
